import { type Signal } from '@angular/core';
import type { AbstractControlDirective, NgControl } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class BrnFormFieldControl {
    /** Gets the AbstractControlDirective for this control. */
    readonly ngControl: NgControl | AbstractControlDirective | null;
    /** Whether the control is in an error state. */
    readonly errorState: Signal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrnFormFieldControl, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BrnFormFieldControl, never, never, {}, {}, never, never, false, never>;
}
