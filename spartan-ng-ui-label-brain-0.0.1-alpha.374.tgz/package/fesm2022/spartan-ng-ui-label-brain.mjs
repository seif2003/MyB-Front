import * as i0 from '@angular/core';
import { inject, input, PLATFORM_ID, ElementRef, signal, Directive, NgModule } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { NgControl } from '@angular/forms';

let nextId = 0;
class BrnLabelDirective {
    constructor() {
        this._ngControl = inject(NgControl, { optional: true });
        this.id = input(`brn-label-${nextId++}`);
        this._isBrowser = isPlatformBrowser(inject(PLATFORM_ID));
        this._element = inject(ElementRef).nativeElement;
        this._dataDisabled = signal('auto');
        this.dataDisabled = this._dataDisabled.asReadonly();
    }
    ngOnInit() {
        if (!this._isBrowser)
            return;
        this._changes = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.attributeName !== 'data-disabled')
                    return;
                // eslint-disable-next-line
                const state = mutation.target.attributes.getNamedItem(mutation.attributeName)?.value === 'true';
                this._dataDisabled.set(state ?? 'auto');
            });
        });
        this._changes?.observe(this._element, {
            attributes: true,
            childList: true,
            characterData: true,
        });
    }
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.5", ngImport: i0, type: BrnLabelDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    /** @nocollapse */ static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "18.2.5", type: BrnLabelDirective, isStandalone: true, selector: "[brnLabel]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "id": "id()", "class.ng-invalid": "this._ngControl?.invalid || null", "class.ng-dirty": "this._ngControl?.dirty || null", "class.ng-valid": "this._ngControl?.valid || null", "class.ng-touched": "this._ngControl?.touched || null" } }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.5", ngImport: i0, type: BrnLabelDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[brnLabel]',
                    standalone: true,
                    host: {
                        '[id]': 'id()',
                        '[class.ng-invalid]': 'this._ngControl?.invalid || null',
                        '[class.ng-dirty]': 'this._ngControl?.dirty || null',
                        '[class.ng-valid]': 'this._ngControl?.valid || null',
                        '[class.ng-touched]': 'this._ngControl?.touched || null',
                    },
                }]
        }] });

class BrnLabelModule {
    /** @nocollapse */ static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.5", ngImport: i0, type: BrnLabelModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    /** @nocollapse */ static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.5", ngImport: i0, type: BrnLabelModule, imports: [BrnLabelDirective], exports: [BrnLabelDirective] }); }
    /** @nocollapse */ static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.5", ngImport: i0, type: BrnLabelModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.5", ngImport: i0, type: BrnLabelModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [BrnLabelDirective],
                    exports: [BrnLabelDirective],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { BrnLabelDirective, BrnLabelModule };
//# sourceMappingURL=spartan-ng-ui-label-brain.mjs.map
